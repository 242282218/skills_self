---
name: code-summarizer
description: 生成代码文件或模块的简洁摘要。
---

# Code Summarizer

生成代码文件或模块的简洁摘要。

## When to Invoke

- 快速了解代码文件功能
- 生成项目文档
- 代码库导航和索引
- 编写 README 或技术文档

## Input Format

```yaml
file_path: "src/auth/middleware.py"
summary_type: "detailed"
```

## Output Format

```yaml
summary: |
  该模块实现了基于 JWT 的认证中间件。
  主要功能包括：Token 验证、权限检查、
  用户上下文注入、错误处理。
key_components:
  - name: "JWTAuthMiddleware"
    type: "class"
    purpose: "主中间件类"
  - name: "validate_token"
    type: "function"
    purpose: "验证 JWT Token"
dependencies:
  - "jwt"
  - "fastapi"
  - "redis"
statistics:
  lines: 150
  functions: 8
  classes: 2
```

## Examples

### Example 1: Python 模块摘要

**Input:** 一个数据处理模块

**Output:**
- 一句话概括：数据清洗和转换模块
- 核心功能列表
- 输入输出格式说明
- 关键配置项

### Example 2: C 头文件摘要

**Input:** 一个网络库头文件

**Output:**
- 模块用途概述
- 导出的函数列表
- 数据结构定义
- 使用注意事项

## Best Practices

1. **金字塔结构**: 最重要的信息放在前面
2. **量化描述**: 使用具体数字（函数数、行数）
3. **职责单一**: 每个模块只描述一个主要职责
4. **依赖透明**: 明确列出外部依赖
