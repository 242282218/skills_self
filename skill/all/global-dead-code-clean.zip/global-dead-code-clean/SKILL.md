---
name: dead-code-clean
description: 清理未使用的代码，减少技术债务。
---

# Dead Code Clean

清理未使用的代码，减少技术债务。

## When to Invoke

- 代码库体积过大
- 维护成本过高
- 遗留代码清理
- 重构前准备
- 代码审查发现冗余

## Input Format

```yaml
project_path: "./src"
entry_points:
  - "main.py"
  - "cli.py"
exclude_patterns:
  - "**/test_*.py"
  - "**/migrations/**"
```

## Output Format

```yaml
dead_code_list:
  unused_functions:
    - name: "legacy_handler"
      file: "handlers.py"
      line: 45
      confidence: "high"
  unused_variables:
    - name: "DEBUG_FLAG"
      file: "config.py"
      line: 12
  unreachable_code:
    - file: "utils.py"
      lines: "100-120"
      reason: "after return statement"

impact_analysis:
  safe_to_remove:
    - "legacy_handler"
  needs_review:
    - "DEBUG_FLAG (可能被动态使用)"

cleanup_plan:
  - step: 1
    action: "删除 legacy_handler"
    files: ["handlers.py"]
  - step: 2
    action: "清理未使用导入"
    files: ["*.py"]

safety_verification:
  - "运行完整测试套件"
  - "检查动态调用 (getattr, eval)"
  - "验证公共 API 完整性"
```

## Examples

### Example 1: 未使用函数

**Detected:**
```python
def unused_helper(x):
    return x * 2  # 从未被调用
```

**Action:** 安全删除

### Example 2: 不可达代码

**Detected:**
```python
def process():
    return result
    print("never reached")  # 死代码
```

**Action:** 删除不可达代码

## Best Practices

1. **逐步清理**: 不要一次性删除太多
2. **测试保护**: 每次删除后运行测试
3. **版本控制**: 保留删除历史
4. **文档更新**: 同步更新相关文档
